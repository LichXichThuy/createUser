package com.nguyenvanvu.createUserController.controller;

import com.nguyenvanvu.createUserController.dto.UserDto;
import com.nguyenvanvu.createUserController.payload.LoginRequest;
import com.nguyenvanvu.createUserController.service.UserServiceImp;
import com.nguyenvanvu.createUserController.service.imp.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/user")
public class UserController {
    @Autowired
    UserService userService;

    @PostMapping("/add")
    public ResponseEntity<?> addUser(@RequestBody UserDto userDto){
        return new ResponseEntity<>(userService.isInsertUser(userDto), HttpStatus.OK);
    }

    @PostMapping("")
    public ResponseEntity<?> login(@RequestBody LoginRequest loginRequest){
        return new ResponseEntity<>(userService.isLoginSucces(loginRequest), HttpStatus.OK);
    }
}
