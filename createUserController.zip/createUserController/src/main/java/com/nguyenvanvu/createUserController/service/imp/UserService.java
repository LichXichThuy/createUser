package com.nguyenvanvu.createUserController.service.imp;

import com.nguyenvanvu.createUserController.dto.UserDto;
import com.nguyenvanvu.createUserController.entity.Users;
import com.nguyenvanvu.createUserController.payload.LoginRequest;
import org.springframework.stereotype.Service;

import java.util.List;


public interface UserService {
    boolean isInsertUser(UserDto userDto);

    boolean isLoginSucces(LoginRequest loginRequest);
}
