package com.nguyenvanvu.createUserController.service;

import com.nguyenvanvu.createUserController.dto.UserDto;
import com.nguyenvanvu.createUserController.entity.Roles;
import com.nguyenvanvu.createUserController.entity.Users;
import com.nguyenvanvu.createUserController.payload.LoginRequest;
import com.nguyenvanvu.createUserController.repository.UserRepository;
import com.nguyenvanvu.createUserController.service.imp.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;


@Service
public class UserServiceImp implements UserService {
    @Autowired
    UserRepository userRepository;

    @Override
    public boolean isInsertUser(UserDto userDto) {
        Roles roles = new Roles();
        roles.setId(userDto.getRoleId());

        Users users = new Users();
        users.setEmail(userDto.getEmail());
        users.setAvatar(userDto.getAvatar());
        users.setFullname(userDto.getFullname());
        users.setPassword(userDto.getPassword());
        users.setRoles(roles);

        try {
            userRepository.save(users);
            return true;
        } catch (Exception e){
            System.err.println("Lỗi update user: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean isLoginSucces(LoginRequest loginRequest) {
        return userRepository.findByEmailAndPassword(loginRequest.getEmail(), loginRequest.getPassword()).size() > 0;
    }
}
