package com.nguyenvanvu.createUserController;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CreateUserControllerApplicationTests {

	@Test
	void contextLoads() {
	}

}
